from django.contrib import admin

from books.models import Book


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    """Enhanced admin interface for Book model"""
    
    list_display = ('title', 'author', 'isbn', 'published_year', 'is_available')
    list_filter = ('is_available', 'published_year')
    search_fields = ('title', 'author', 'isbn')
    ordering = ('-published_year', 'title')
    
    fieldsets = (
        ('Book Information', {
            'fields': ('title', 'author', 'isbn')
        }),
        ('Details', {
            'fields': ('published_year', 'is_available')
        }),
    )
    
    def has_add_permission(self, request):
        return True
    
    def has_change_permission(self, request, obj=None):
        return True
    
    def has_delete_permission(self, request, obj=None):
        return True
    
    def has_view_permission(self, request, obj=None):
        return True