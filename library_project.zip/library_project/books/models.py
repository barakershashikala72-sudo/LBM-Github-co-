from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=200)       # Book title
    author = models.CharField(max_length=100)      # Author name
    isbn = models.CharField(max_length=13, unique=True)  # Unique book ID
    published_year = models.IntegerField()
    is_available = models.BooleanField(default=True)  # Is the book in stock?

    def __str__(self):
        # This is like a toString() — shown in Django admin
        return f"{self.title} by {self.author}"
