from rest_framework import serializers
from .models import Book


class BookSerializer(serializers.ModelSerializer):
    """Serializer for Book model - converts Book objects to/from JSON"""
    
    class Meta:
        model = Book
        fields = ['id', 'title', 'author', 'isbn', 'published_year', 'is_available']
        read_only_fields = ['id']  # ID is auto-generated
