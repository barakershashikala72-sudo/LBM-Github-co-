from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Create a router and register the viewset
router = DefaultRouter()
router.register(r'books', views.BookViewSet, basename='book')

urlpatterns = [
    # API endpoints
    path('api/', include(router.urls)),
    
    # Frontend home page
    path('', views.home, name='home'),
]
