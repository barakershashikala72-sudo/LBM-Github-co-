from django.shortcuts import render
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Book
from .serializers import BookSerializer


class BookViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for Book model
    Provides CRUD operations:
    - GET /api/books/ - List all books
    - POST /api/books/ - Create new book
    - GET /api/books/{id}/ - Get single book
    - PUT /api/books/{id}/ - Update entire book
    - PATCH /api/books/{id}/ - Partial update book
    - DELETE /api/books/{id}/ - Delete book
    """
    queryset = Book.objects.all()
    serializer_class = BookSerializer
    
    @action(detail=False, methods=['get'])
    def available(self, request):
        """Get only available books"""
        available_books = Book.objects.filter(is_available=True)
        serializer = self.get_serializer(available_books, many=True)
        return Response(serializer.data)
    
    @action(detail=True, methods=['post'])
    def toggle_availability(self, request, pk=None):
        """Toggle book availability status"""
        book = self.get_object()
        book.is_available = not book.is_available
        book.save()
        serializer = self.get_serializer(book)
        return Response(serializer.data)


# Home page view for frontend
def home(request):
    """Render the home page"""
    return render(request, 'home.html')
                                        
